ls| cpio -o archive.cpio

ls | cpio -o archive.cpio
ls | cpio -i < archive.cpio
ls | cpio -p /home/student/Desktop/scripts 
ls | cpio -ov  archive2.cpio
ls | cpio -iv < archive2.cpio
ls | cpio -ov -H tar > output.tar
 
 
 
 
 
