sed 's/Gnaneshwarss/Pravallika/' file1.txt
sed '2d' file1.txt
sed '1d' file1.txt
sed '$d' file1.txt
sed '1,4d' file1.txt
sed '4,$d' file1.txt
sed '/22/d' file1.txt
cat file1.txt
