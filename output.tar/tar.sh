tar cvf file1.tar file1.txt
tar xvf file1.tar
tar cvzf file1.tar.gz awkoutput.txt
tar xvzf file1.tar.gz
tar cvfj file1.tar.tbz awkoutput.txt
tar xvfj file1.tar.tbz
tar czf file1.tar | wc -c
tar rvf file1.tar awkoutput.txt
tar tf file1.tar
tar tvf file1.tar file1.txt
tar tvf file1.tar
tar xvf file1.tar "file1.txt" "awkoutput.txt"
